package com.huawei.mbbcloud.simplesworkflow.dao;

import com.huawei.mbbcloud.simplesworkflow.model.po.StateFlowPO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface StateFlowDao {
    List<StateFlowPO> listFlowByFromState(String fromStateKeyword);
}
