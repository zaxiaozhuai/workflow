package com.huawei.mbbcloud.simplesworkflow.model.param;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

@Data
public class WorkFlowProcessParam {
    private String taskId;
    private String serverId;
    private JSONObject businessParam;
}
