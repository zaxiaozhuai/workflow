package com.huawei.mbbcloud.simplesworkflow.dao;

import com.huawei.mbbcloud.simplesworkflow.model.po.InstancePO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface InstanceDao {
    void insert(InstancePO instancePO);
}
