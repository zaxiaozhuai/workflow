package com.huawei.mbbcloud.simplesworkflow.model.po;

import lombok.Data;

@Data
public class TaskPO {
    private int id;
    private int processId;
    private int stateId;
    private String owner;
    private String possessor;
    private String tenant;
}
