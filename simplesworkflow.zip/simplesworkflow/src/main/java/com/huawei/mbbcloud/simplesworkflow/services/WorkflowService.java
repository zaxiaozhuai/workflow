package com.huawei.mbbcloud.simplesworkflow.services;

import com.huawei.mbbcloud.simplesworkflow.dao.*;
import com.huawei.mbbcloud.simplesworkflow.model.param.WorkFlowStartParam;
import com.huawei.mbbcloud.simplesworkflow.model.po.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class WorkflowService {
    @Autowired
    private ProcessDao processDao;
    @Autowired
    private InstanceDao instanceDao;
    @Autowired
    private StateDao stateDao;
    @Autowired
    private RoleUserDao roleUserDao;
    @Autowired
    private TaskDao taskDao;
    @Autowired
    private StateFlowDao stateFlowDao;

    public Optional<ProcessPO> getProcessByKeyword(String keyword, String tenant) {
        ProcessPO process = processDao.getByKeyword(keyword, tenant);
        return Optional.ofNullable(process);
    }

    public void createInstance(ProcessPO process, WorkFlowStartParam startParam, String userId) {
        InstancePO instancePO = new InstancePO();
        instancePO.setBusinessKey(startParam.getBusinessKey());
        instancePO.setKeyword(startParam.getKeyword());
        instancePO.setProcessId(process.getId());
        instancePO.setTenant(startParam.getServerId());
        instancePO.setStartState(process.getStartState());
        instancePO.setCreateUser(userId);
        instanceDao.insert(instancePO);
    }

    public List<StatePO> listStateByProcessId(int processId) {
        List<StatePO> states = stateDao.listStateByProcessId(processId);
        return states;
    }

    public Optional<StatePO> getStateBykeyword(String keyword) {
        StatePO state = stateDao.getStateByKey(keyword);
        return Optional.ofNullable(state);
    }

    public StatePO getStateById(int id) {
        return stateDao.getStateById(id);
    }

    public String getPossessorByRole(String roleId) {
        List<RoleUserPO> users = roleUserDao.listByRoleId(roleId);
        return users.stream().map(u -> u.getUserId()).collect(Collectors.joining(","));
    }

    public void insertTask(TaskPO task) {
        taskDao.insert(task);
    }

    public List<TaskPO> listTask(String possessor, String tenant) {
        return taskDao.listTaskByPossessor(possessor, tenant);
    }

    public TaskPO getTaskById(String taskId, String tenant) {
        return taskDao.getTaskById(taskId, tenant);
    }

    public List<StateFlowPO> listFlow(String stateKeyword) {
        return stateFlowDao.listFlowByFromState(stateKeyword);
    }

    public void deleteTask(int taskId) {
        taskDao.delete(taskId);
    }

}
