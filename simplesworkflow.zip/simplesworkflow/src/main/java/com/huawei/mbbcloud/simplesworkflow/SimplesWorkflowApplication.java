package com.huawei.mbbcloud.simplesworkflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplesWorkflowApplication {
    public static void main(String[] args) {
        SpringApplication.run(SimplesWorkflowApplication.class, args);
    }
}
