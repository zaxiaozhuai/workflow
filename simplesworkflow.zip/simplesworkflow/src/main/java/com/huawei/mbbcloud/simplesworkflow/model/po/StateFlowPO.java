package com.huawei.mbbcloud.simplesworkflow.model.po;

import lombok.Data;

@Data
public class StateFlowPO {
    private int id;
    private String fromStateKeyword;
    private String toStateKeyword;
    private String condition;
    private String user;
}
