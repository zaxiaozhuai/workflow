package com.huawei.mbbcloud.simplesworkflow.dao;

import com.huawei.mbbcloud.simplesworkflow.model.po.StatePO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface StateDao {
    List<StatePO> listStateByProcessId(int processId);

    StatePO getStartStateByProcessId(int processId);

    StatePO getStateByKey(String keyword);

    StatePO getStateById(int id);
}
