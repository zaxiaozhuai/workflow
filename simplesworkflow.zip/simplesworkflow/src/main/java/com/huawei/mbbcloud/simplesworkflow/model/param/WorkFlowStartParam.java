package com.huawei.mbbcloud.simplesworkflow.model.param;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import java.util.Map;

@Data
public class WorkFlowStartParam {
    private String keyword;
    private String businessKey;
    private String serverId;
    private JSONObject businessParam;
}
