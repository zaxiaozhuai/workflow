package com.huawei.mbbcloud.simplesworkflow.model.po;

import lombok.Data;

import java.util.Date;

@Data
public class ProcessPO {
    private int id;
    private String nameCn;
    private String nameEn;
    private String keyword;
    private String tenant;
    private String startState;
    private Date createTime;
}
