package com.huawei.mbbcloud.simplesworkflow.dao;

import com.huawei.mbbcloud.simplesworkflow.model.po.ProcessPO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ProcessDao {
    ProcessPO getByKeyword(@Param("keyword") String keyword, @Param("tenant") String tenant);
}
