package com.huawei.mbbcloud.simplesworkflow.common.exception;

public class WorkflowException extends Exception {
    public WorkflowException(String msg) {
        super(msg);
    }
}
