package com.huawei.mbbcloud.simplesworkflow.common;

import lombok.Data;

@Data
public class ResponseResult<T> {
    private int code;
    private String message;
    private T data;
}
