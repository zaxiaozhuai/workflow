package com.huawei.mbbcloud.simplesworkflow.model.po;

import lombok.Data;

@Data
public class RoleUserPO {
    private int id;
    private String roleId;
    private String userId;
    private String tenant;
}
