package com.huawei.mbbcloud.simplesworkflow.model.po;

import lombok.Data;

@Data
public class StatePO {
    private int id;
    private int processId;
    private String nameCn;
    private String nameEn;
    private String keyword;
    private String condition;
    private String user;
    private String toState;
}
