package com.huawei.mbbcloud.simplesworkflow.model.po;

import lombok.Data;

@Data
public class InstancePO {
    private int id;
    private int processId;
    private String businessKey;
    private String keyword;
    private String startState;
    private String tenant;
    private String createUser;
}
