package com.huawei.mbbcloud.simplesworkflow.model.param;

import lombok.Data;

@Data
public class WorkFlowQueryParam {
    private String serverId;
}
