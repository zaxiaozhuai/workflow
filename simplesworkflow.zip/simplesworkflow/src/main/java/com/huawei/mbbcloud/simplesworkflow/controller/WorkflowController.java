package com.huawei.mbbcloud.simplesworkflow.controller;

import com.alibaba.fastjson.JSONObject;
import com.huawei.mbbcloud.simplesworkflow.common.ResponseResult;
import com.huawei.mbbcloud.simplesworkflow.model.param.WorkFlowProcessParam;
import com.huawei.mbbcloud.simplesworkflow.model.param.WorkFlowQueryParam;
import com.huawei.mbbcloud.simplesworkflow.model.param.WorkFlowStartParam;
import com.huawei.mbbcloud.simplesworkflow.model.po.ProcessPO;
import com.huawei.mbbcloud.simplesworkflow.model.po.StateFlowPO;
import com.huawei.mbbcloud.simplesworkflow.model.po.StatePO;
import com.huawei.mbbcloud.simplesworkflow.model.po.TaskPO;
import com.huawei.mbbcloud.simplesworkflow.services.WorkflowService;
import javafx.concurrent.Task;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/workflow")
public class WorkflowController {
    @Autowired
    private WorkflowService workflowService;

    @PostMapping("/start")
    @ResponseBody
    public ResponseResult start(@RequestBody WorkFlowStartParam startParam, HttpServletRequest request) {
        Optional<ProcessPO> processOptional = workflowService.getProcessByKeyword(startParam.getKeyword(), startParam.getServerId());
        ProcessPO process = processOptional.get();
        String userId = request.getHeader("userId");
        workflowService.createInstance(process, startParam, userId);

        Optional<StatePO> statePOOptional = workflowService.getStateBykeyword(process.getStartState());
        StatePO statePO = statePOOptional.get();
        String user = statePO.getUser();
        ResponseResult result = new ResponseResult();

        if (StringUtils.isEmpty(user)) {
            result.setCode(500);
            result.setMessage("Can not find processor!");
            return result;
        }
        String possessor = user;
        if (user.contains("$")) {
            String userParam = user.substring(1);
            JSONObject businessParam = startParam.getBusinessParam();
            possessor = businessParam.getString(userParam);
        } else {
            possessor = workflowService.getPossessorByRole(user);
        }

        if (StringUtils.isEmpty(possessor)) {
            result.setCode(500);
            result.setMessage("Can not find processor!");
            return result;
        }

        TaskPO task = new TaskPO();
        task.setProcessId(process.getId());
        task.setStateId(statePO.getId());
        task.setOwner(userId);
        task.setPossessor(possessor);
        task.setTenant(startParam.getServerId());

        workflowService.insertTask(task);

        result.setCode(200);
        result.setMessage("success");
        return result;
    }

    @PostMapping("/listTask")
    @ResponseBody
    public ResponseResult<List<TaskPO>> listTask(@RequestBody WorkFlowQueryParam queryParam, HttpServletRequest request) {
        String userId = request.getHeader("userId");
        String tenant = queryParam.getServerId();
        List<TaskPO> tasks = workflowService.listTask(userId, tenant);

        ResponseResult<List<TaskPO>> result = new ResponseResult<>();
        result.setCode(200);
        result.setMessage("success");
        result.setData(tasks);
        return result;
    }


    @PostMapping("/process")
    @ResponseBody
    public ResponseResult<String> process(@RequestBody WorkFlowProcessParam processParam, HttpServletRequest request) {
        String userId = request.getHeader("userId");
        String tenant = processParam.getServerId();
        TaskPO task = workflowService.getTaskById(processParam.getTaskId(), tenant);
        ResponseResult<String> result = new ResponseResult<>();
        if (task == null) {
            result.setMessage("task not found!");
            result.setCode(500);
            return result;
        }
        String possessor = task.getPossessor();
        if (StringUtils.isEmpty(possessor) || !possessor.contains(userId)) {
            result.setMessage("You are not the possessor!");
            result.setCode(500);
            return result;
        }
        StatePO state = workflowService.getStateById(task.getStateId());
        if (state == null) {
            result.setMessage("Process Error! state not found!");
            result.setCode(500);
            return result;
        }
        List<StateFlowPO> flows = workflowService.listFlow(state.getKeyword());
        if (flows.isEmpty()) {
            result.setMessage("Process Error! State flow is empty!");
            result.setCode(500);
            return result;
        }
        String toState = null;
        for (StateFlowPO flow : flows) {
            String condition = flow.getCondition();
            if (StringUtils.isEmpty(condition)) {
                continue;
            }
            String trimCondition = condition.replaceAll(" ", "");
            String[] params = trimCondition.split("=");
            String paramName = params[0];
            JSONObject paramObj = processParam.getBusinessParam();
            String value = paramObj.getString(paramName);
            String conditionValue = params[1];
            if (StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(conditionValue) && conditionValue.equalsIgnoreCase(value)) {
                toState = flow.getToStateKeyword();
                break;
            }
        }
        if (StringUtils.isEmpty(toState)) {
            toState = flows.get(0).getToStateKeyword();
        }

        if (toState.equalsIgnoreCase("end")) {
            result.setCode(200);
            result.setMessage("finished!");
            return result;
        }

        Optional<StatePO> statePOOptional = workflowService.getStateBykeyword(toState);
        StatePO statePO = statePOOptional.get();
        String user = statePO.getUser();

        if (StringUtils.isEmpty(user)) {
            result.setCode(500);
            result.setMessage("Can not find processor!");
            return result;
        }
        String nextPossessor = user;
        if (user.contains("$")) {
            String userParam = user.substring(1);
            JSONObject businessParam = processParam.getBusinessParam();
            possessor = businessParam.getString(userParam);
        } else {
            nextPossessor = workflowService.getPossessorByRole(user);
        }

        if (StringUtils.isEmpty(nextPossessor)) {
            result.setCode(500);
            result.setMessage("Can not find processor!");
            return result;
        }

        TaskPO nextTask = new TaskPO();
        nextTask.setProcessId(statePO.getProcessId());
        nextTask.setStateId(statePO.getId());
        nextTask.setOwner(task.getOwner());
        nextTask.setPossessor(nextPossessor);
        nextTask.setTenant(processParam.getServerId());

        workflowService.insertTask(nextTask);
        workflowService.deleteTask(task.getId());

        result.setCode(200);
        result.setMessage("success");
        return result;
    }
}
