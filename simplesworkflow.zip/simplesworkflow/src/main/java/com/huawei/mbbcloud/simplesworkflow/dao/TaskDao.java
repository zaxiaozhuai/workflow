package com.huawei.mbbcloud.simplesworkflow.dao;

import com.huawei.mbbcloud.simplesworkflow.model.po.TaskPO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TaskDao {
    void insert(TaskPO task);

    void delete(int taskId);

    List<TaskPO> listTaskByPossessor(String possessor, String tenant);

    TaskPO getTaskById(String taskId, String tenant);
}
