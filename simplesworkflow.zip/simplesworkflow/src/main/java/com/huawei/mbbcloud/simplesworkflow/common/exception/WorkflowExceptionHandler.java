package com.huawei.mbbcloud.simplesworkflow.common.exception;

import com.huawei.mbbcloud.simplesworkflow.common.ResponseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class WorkflowExceptionHandler {
    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * 处理自定义异常
     */
    @ExceptionHandler(Exception.class)
    public ResponseResult<String> handleException(Exception e){
        ResponseResult<String> result = new ResponseResult<>();
        result.setCode(500);
        result.setMessage(e.getMessage());
        return result;
    }
}