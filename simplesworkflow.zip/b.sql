/*
SQLyog Ultimate v12.5.1 (64 bit)
MySQL - 5.7.27 : Database - workflow
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`workflow` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `workflow`;

/*Table structure for table `t_workflow_instance` */

DROP TABLE IF EXISTS `t_workflow_instance`;

CREATE TABLE `t_workflow_instance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `business_key` varchar(200) NOT NULL,
  `keyword` varchar(200) NOT NULL,
  `start_state` varchar(200) NOT NULL,
  `tenant` varchar(200) NOT NULL,
  `create_user` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `t_workflow_instance` */

/*Table structure for table `t_workflow_process` */

DROP TABLE IF EXISTS `t_workflow_process`;

CREATE TABLE `t_workflow_process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_cn` varchar(200) NOT NULL,
  `name_en` varchar(200) NOT NULL,
  `keyword` varchar(200) NOT NULL,
  `tenant` varchar(200) NOT NULL,
  `start_state` varchar(200) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

/*Data for the table `t_workflow_process` */

insert  into `t_workflow_process`(`id`,`name_cn`,`name_en`,`keyword`,`tenant`,`start_state`,`create_time`) values 
(1,'场景包下载','scene Download','sceneDownload','wra','sceneDownload_department','2021-04-24 23:50:47');

/*Table structure for table `t_workflow_role` */

DROP TABLE IF EXISTS `t_workflow_role`;

CREATE TABLE `t_workflow_role` (
  `id` varchar(60) NOT NULL,
  `role_name_cn` varchar(200) NOT NULL,
  `role_name_en` varchar(200) NOT NULL,
  `tenant` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `t_workflow_role` */

/*Table structure for table `t_workflow_role_user` */

DROP TABLE IF EXISTS `t_workflow_role_user`;

CREATE TABLE `t_workflow_role_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` varchar(60) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `tenant` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `t_workflow_role_user` */

/*Table structure for table `t_workflow_state` */

DROP TABLE IF EXISTS `t_workflow_state`;

CREATE TABLE `t_workflow_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `name_cn` varchar(200) NOT NULL,
  `name_en` varchar(200) NOT NULL,
  `keyword` varchar(200) NOT NULL,
  `condition` varchar(500) DEFAULT NULL,
  `user` varchar(200) DEFAULT NULL,
  `to_state` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `t_workflow_state` */

insert  into `t_workflow_state`(`id`,`process_id`,`name_cn`,`name_en`,`keyword`,`condition`,`user`,`to_state`) values 
(1,1,'业务部门审批','Business supervisor approve','sceneDownload_department',NULL,NULL,'sceneDownload_system'),
(2,1,'系统管理员审批','System manager approve','sceneDownload_system',NULL,NULL,'end');

/*Table structure for table `t_workflow_state_flow` */

DROP TABLE IF EXISTS `t_workflow_state_flow`;

CREATE TABLE `t_workflow_state_flow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_state_keyword` varchar(200) NOT NULL,
  `to_state_keyword` varchar(200) NOT NULL,
  `condition` varchar(500) DEFAULT NULL,
  `user` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

/*Data for the table `t_workflow_state_flow` */

insert  into `t_workflow_state_flow`(`id`,`from_state_keyword`,`to_state_keyword`,`condition`,`user`) values 
(1,'sceneDownload_department','sceneDownload_system',NULL,NULL);

/*Table structure for table `t_workflow_task` */

DROP TABLE IF EXISTS `t_workflow_task`;

CREATE TABLE `t_workflow_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `state_id` varchar(200) NOT NULL,
  `owner` varchar(200) NOT NULL,
  `possessor` varchar(500) DEFAULT NULL,
  `tenant` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `t_workflow_task` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
