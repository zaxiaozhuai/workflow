package com.qjc.mapper;

import com.qjc.entity.TOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author astupidcoder
 * @since 2021-03-25
 */
@Repository
public interface TOrderMapper extends BaseMapper<TOrder> {
    List<TOrder> findOrderListByPage();
}
