package com.qjc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qjc.entity.TOrder;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author astupidcoder
 * @since 2021-03-25
 */
public interface ITOrderService extends IService<TOrder> {

    List<TOrder> findOrderListByPage();

}
